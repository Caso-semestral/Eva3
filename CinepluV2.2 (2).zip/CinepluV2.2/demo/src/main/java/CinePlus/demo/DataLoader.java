package CinePlus.demo;

import CinePlus.demo.model.*;
import CinePlus.demo.repository.*;

import net.datafaker.Faker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Random;

@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private PeliculaRepository peliculaRepository;

    @Autowired
    private EntradaRepository entradaRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private LicenciaRepository licenciaRepository;

    @Autowired
    private SuscripcionRepository suscripcionRepository;

    @Override
    public void run(String... args) throws Exception {

        Faker faker = new Faker();
        Random random = new Random();

        // Generar licencias
        for (int i = 0; i < 5; i++) {

            Licencia licencia = new Licencia();

            licencia.setTipo(
                faker.options().option(
                    "Streaming",
                    "Distribucion",
                    "Exhibicion"
                )
            );

            licencia.setCodigo(
                faker.code().isbn10()
            );

            licenciaRepository.save(licencia);
        }

        // Generar suscripciones
        for (int i = 0; i < 5; i++) {

            Suscripcion suscripcion = new Suscripcion();

            suscripcion.setPlan(
                faker.options().option(
                    "Basico",
                    "Estandar",
                    "Premium"
                )
            );

            suscripcion.setAccesoStreaming(
                faker.bool().bool()
            );

            suscripcionRepository.save(suscripcion);
        }

        // Generar usuarios
        for (int i = 0; i < 20; i++) {

            Usuario usuario = new Usuario();

            usuario.setNombre(
                faker.name().fullName()
            );

            usuario.setEmail(
                faker.internet().emailAddress()
            );

            usuarioRepository.save(usuario);
        }

        // Generar peliculas
        for (int i = 0; i < 15; i++) {

            Pelicula pelicula = new Pelicula();

            pelicula.setTitulo(
                faker.book().title()
            );

            pelicula.setGenero(
                faker.book().genre()
            );

            pelicula.setEsIndependiente(
                faker.bool().bool()
            );

            peliculaRepository.save(pelicula);
        }

        List<Usuario> usuarios =
                usuarioRepository.findAll();

        List<Pelicula> peliculas =
                peliculaRepository.findAll();

        // Generar entradas
        for (int i = 0; i < 50; i++) {

            Entrada entrada = new Entrada();

            Usuario usuario =
                    usuarios.get(
                            random.nextInt(
                                    usuarios.size()
                            )
                    );

            Pelicula pelicula =
                    peliculas.get(
                            random.nextInt(
                                    peliculas.size()
                            )
                    );

            entrada.setUsuarioId(
                    usuario.getId()
            );

            entrada.setPeliculaId(
                    pelicula.getId().longValue()
            );

            entrada.setPrecio(
                    faker.number()
                            .numberBetween(
                                    3000,
                                    12000
                            )
            );

            entradaRepository.save(entrada);
        }

        System.out.println(
                "Datos Faker cargados correctamente"
        );
    }
}