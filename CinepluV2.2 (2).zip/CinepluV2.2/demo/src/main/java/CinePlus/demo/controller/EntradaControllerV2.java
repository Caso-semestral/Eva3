package CinePlus.demo.controller;

import CinePlus.demo.assemblers.EntradaModelAssembler;
import CinePlus.demo.model.Entrada;
import CinePlus.demo.services.EntradaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v2/entradas")
public class EntradaControllerV2 {

    @Autowired
    private EntradaService entradaService;

    @Autowired
    private EntradaModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public CollectionModel<EntityModel<Entrada>> getAllEntradas() {
        List<EntityModel<Entrada>> entradas = entradaService.findAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(entradas,
                linkTo(methodOn(EntradaControllerV2.class).getAllEntradas()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public EntityModel<Entrada> getEntradaById(@PathVariable Long id) {
        Entrada entrada = entradaService.findById(id);
        return assembler.toModel(entrada);
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Entrada>> createEntrada(@RequestBody Entrada entrada) {
        Entrada newEntrada = entradaService.save(entrada);
        return ResponseEntity
                .created(linkTo(methodOn(EntradaControllerV2.class).getEntradaById(newEntrada.getId())).toUri())
                .body(assembler.toModel(newEntrada));
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Entrada>> updateEntrada(@PathVariable Long id, @RequestBody Entrada entrada) {
        entrada.setId(id);
        Entrada updatedEntrada = entradaService.save(entrada);
        return ResponseEntity.ok(assembler.toModel(updatedEntrada));
    }

    @DeleteMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<?> deleteEntrada(@PathVariable Long id) {
        entradaService.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    // Método 1: entradas de un usuario específico
    @GetMapping(value = "/usuario/{usuarioId}", produces = MediaTypes.HAL_JSON_VALUE)
    public CollectionModel<EntityModel<Entrada>> getEntradasByUsuario(@PathVariable Long usuarioId) {
        List<EntityModel<Entrada>> entradas = entradaService.findByUsuarioId(usuarioId).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(entradas,
                linkTo(methodOn(EntradaControllerV2.class).getEntradasByUsuario(usuarioId)).withSelfRel(),
                linkTo(methodOn(EntradaControllerV2.class).getAllEntradas()).withRel("entradas"));
    }

    // Método 2: entradas de una película específica
    @GetMapping(value = "/pelicula/{peliculaId}", produces = MediaTypes.HAL_JSON_VALUE)
    public CollectionModel<EntityModel<Entrada>> getEntradasByPelicula(@PathVariable Long peliculaId) {
        List<EntityModel<Entrada>> entradas = entradaService.findByPeliculaId(peliculaId).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(entradas,
                linkTo(methodOn(EntradaControllerV2.class).getEntradasByPelicula(peliculaId)).withSelfRel(),
                linkTo(methodOn(EntradaControllerV2.class).getAllEntradas()).withRel("entradas"));
    }

    // Método 3: entradas de un usuario en una película específica
    @GetMapping(value = "/usuario/{usuarioId}/pelicula/{peliculaId}", produces = MediaTypes.HAL_JSON_VALUE)
    public CollectionModel<EntityModel<Entrada>> getEntradasByUsuarioAndPelicula(
            @PathVariable Long usuarioId,
            @PathVariable Long peliculaId) {
        List<EntityModel<Entrada>> entradas = entradaService
                .findByUsuarioIdAndPeliculaId(usuarioId, peliculaId).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(entradas,
                linkTo(methodOn(EntradaControllerV2.class)
                        .getEntradasByUsuarioAndPelicula(usuarioId, peliculaId)).withSelfRel(),
                linkTo(methodOn(EntradaControllerV2.class).getAllEntradas()).withRel("entradas"));
    }

    // Método 4: entradas con precio menor o igual
    @GetMapping(value = "/precio/{precio}", produces = MediaTypes.HAL_JSON_VALUE)
    public CollectionModel<EntityModel<Entrada>> getEntradasByPrecio(@PathVariable double precio) {
        List<EntityModel<Entrada>> entradas = entradaService.findByPrecioLessThanEqual(precio).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(entradas,
                linkTo(methodOn(EntradaControllerV2.class).getEntradasByPrecio(precio)).withSelfRel(),
                linkTo(methodOn(EntradaControllerV2.class).getAllEntradas()).withRel("entradas"));
    }

    // Método 5: total de entradas de un usuario
    @GetMapping(value = "/usuario/{usuarioId}/total", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<?> countEntradasByUsuario(@PathVariable Long usuarioId) {
        long total = entradaService.countByUsuarioId(usuarioId);
        return ResponseEntity.ok(
                java.util.Map.of(
                        "usuarioId", usuarioId,
                        "totalEntradas", total,
                        "_links", java.util.Map.of(
                                "entradas", java.util.Map.of(
                                        "href", linkTo(methodOn(EntradaControllerV2.class)
                                                .getAllEntradas()).toUri().toString()))));
    }
}

