package CinePlus.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import CinePlus.demo.model.Licencia;

@Repository
public interface LicenciaRepository extends JpaRepository<Licencia, Long> {

}