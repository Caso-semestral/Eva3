package CinePlus.demo.controller;

import CinePlus.demo.services.PeliculaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import CinePlus.demo.model.Pelicula;

import java.util.List;



@RestController
@RequestMapping("/api/peliculas")
@CrossOrigin(origins = "*") // Habilitar CORS para conexiones externas [cite: 9]
public class PeliculaController {
  @Autowired
  private PeliculaService service;
  @GetMapping
  public List<Pelicula> getAll() { return service.listarTodo(); }
  @PostMapping
  public Pelicula create(@RequestBody Pelicula p) { return service.guardar(p); }
  @DeleteMapping("/{id}")
  public void delete(@PathVariable Integer id) { service.eliminar(id); }
}