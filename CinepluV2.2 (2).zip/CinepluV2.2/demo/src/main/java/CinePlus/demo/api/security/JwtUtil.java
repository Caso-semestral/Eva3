package CinePlus.demo.api.security;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import org.springframework.stereotype.Service;
import java.util.Date;



@Service

public class JwtUtil {
    private final String SECRET_KEY = "clave_secreta_cineplus_2026";
    private final String ISSUER = "CinepluAPI";


    public String generarToken(String username) {
        return JWT.create()

                .withIssuer(ISSUER)
                .withSubject(username)
                .withExpiresAt(new Date(System.currentTimeMillis() + 3600000)) // Expira en 1 hora
                .sign(Algorithm.HMAC256(SECRET_KEY));
    }

    public String validarToken(String token) {
        try {
            return JWT.require(Algorithm.HMAC256(SECRET_KEY))
                    .withIssuer(ISSUER)
                    .build()
                    .verify(token)
                    .getSubject();
        } catch (JWTVerificationException exception) {
            return null;

        }

    }

}