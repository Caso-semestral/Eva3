package CinePlus.demo.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import CinePlus.demo.controller.EntradaControllerV2;
import CinePlus.demo.model.Entrada;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class EntradaModelAssembler implements RepresentationModelAssembler<Entrada, EntityModel<Entrada>> {

    @Override
    public EntityModel<Entrada> toModel(Entrada entrada) {
        return EntityModel.of(entrada,
                linkTo(methodOn(EntradaControllerV2.class).getEntradaById(entrada.getId())).withSelfRel(),
                linkTo(methodOn(EntradaControllerV2.class).getAllEntradas()).withRel("entradas"));
    }
}