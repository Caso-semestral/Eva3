package CinePlus.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import CinePlus.demo.model.Pelicula;
import CinePlus.demo.repository.PeliculaRepository;

import java.util.List;

@Service
public class PeliculaService {

    @Autowired
    private PeliculaRepository repository;

    public List<Pelicula> listarTodo() {
        return repository.findAll();
    }

    public Pelicula guardar(Pelicula p) {
        return repository.save(p);
    }

    public void eliminar(Integer id) {
        repository.deleteById(id);
    }
}