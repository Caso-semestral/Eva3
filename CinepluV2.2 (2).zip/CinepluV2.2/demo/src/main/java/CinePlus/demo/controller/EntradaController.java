package CinePlus.demo.controller;

import CinePlus.demo.model.Entrada;
import CinePlus.demo.services.EntradaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/entradas")
public class EntradaController {

    @Autowired
    private EntradaService entradaService;

    @GetMapping
    public ResponseEntity<List<Entrada>> getAllEntradas() {
        return ResponseEntity.ok(entradaService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Entrada> getEntradaById(@PathVariable Long id) {
        return ResponseEntity.ok(entradaService.findById(id));
    }

    @PostMapping
    public ResponseEntity<Entrada> createEntrada(@RequestBody Entrada entrada) {
        return ResponseEntity.ok(entradaService.save(entrada));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Entrada> updateEntrada(@PathVariable Long id, @RequestBody Entrada entrada) {
        entrada.setId(id);
        return ResponseEntity.ok(entradaService.save(entrada));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteEntrada(@PathVariable Long id) {
        entradaService.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}