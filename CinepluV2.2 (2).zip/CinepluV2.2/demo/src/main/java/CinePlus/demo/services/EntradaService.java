package CinePlus.demo.services;

import CinePlus.demo.model.Entrada;
import CinePlus.demo.repository.EntradaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EntradaService {

    @Autowired
    private EntradaRepository entradaRepository;

    public List<Entrada> findAll() {
        return entradaRepository.findAll();
    }

    public Entrada findById(Long id) {
        return entradaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Entrada no encontrada con id: " + id));
    }

    public Entrada save(Entrada entrada) {
        return entradaRepository.save(entrada);
    }

    public void deleteById(Long id) {
        entradaRepository.deleteById(id);
    }

    // Método 1: entradas de un usuario específico
    public List<Entrada> findByUsuarioId(Long usuarioId) {
        return entradaRepository.findByUsuarioId(usuarioId);
    }

    // Método 2: entradas de una película específica
    public List<Entrada> findByPeliculaId(Long peliculaId) {
        return entradaRepository.findByPeliculaId(peliculaId);
    }

    // Método 3: entradas de un usuario en una película específica
    public List<Entrada> findByUsuarioIdAndPeliculaId(Long usuarioId, Long peliculaId) {
        return entradaRepository.findByUsuarioIdAndPeliculaId(usuarioId, peliculaId);
    }

    // Método 4: entradas con precio menor o igual a un valor
    public List<Entrada> findByPrecioLessThanEqual(double precio) {
        return entradaRepository.findByPrecioLessThanEqual(precio);
    }

    // Método 5: total de entradas de un usuario
    public long countByUsuarioId(Long usuarioId) {
        return entradaRepository.countByUsuarioId(usuarioId);
    }
}