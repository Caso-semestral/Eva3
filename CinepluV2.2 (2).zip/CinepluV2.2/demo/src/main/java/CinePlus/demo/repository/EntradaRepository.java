package CinePlus.demo.repository;

import CinePlus.demo.model.Entrada;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface EntradaRepository extends JpaRepository<Entrada, Long> {

    // Método 1: por usuarioId
    List<Entrada> findByUsuarioId(Long usuarioId);

    // Método 2: por peliculaId
    List<Entrada> findByPeliculaId(Long peliculaId);

    // Método 3: por usuarioId y peliculaId
    List<Entrada> findByUsuarioIdAndPeliculaId(Long usuarioId, Long peliculaId);

    // Método 4: por precio menor o igual
    List<Entrada> findByPrecioLessThanEqual(double precio);

    // Método 5: contar entradas por usuarioId
    long countByUsuarioId(Long usuarioId);
}